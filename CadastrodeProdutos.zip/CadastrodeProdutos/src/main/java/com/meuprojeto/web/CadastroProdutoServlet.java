package com.meuprojeto.web;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;


public class CadastroProdutoServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String nome = request.getParameter("nome");
        String preco = request.getParameter("preco");

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<h1>Produto Cadastrado com Sucesso!</h1>");
        out.println("<p>Nome do Produto: " + nome + "</p>");
        out.println("<p>Pre�o: R$" + preco + "</p>");
        out.println("<a href='/cadastro-produto.html'>Cadastrar outro produto</a>");
	}

}
