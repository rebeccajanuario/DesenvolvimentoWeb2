package com.meuprojeto.web;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Servlet implementation class CadastroClienteServlet
 */
public class CadastroClienteServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		        response.setContentType("text/html");
		        PrintWriter out = response.getWriter();
		        out.println("<h1>Cadastro de Clientes</h1>");
		        out.println("<p>Aqui voc� poder� cadastrar novos clientes (em breve).</p>");
		        out.println("<a href='/'>Voltar � P�gina Inicial</a>");
	}


}
