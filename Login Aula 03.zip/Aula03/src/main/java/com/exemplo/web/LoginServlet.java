package com.exemplo.web;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 String username = request.getParameter("username");
	        String password = request.getParameter("password");

	        response.setContentType("text/html");
	        PrintWriter out = response.getWriter();

	        // L�gica de verifica��o simples
	        if ("admin".equals(username) && "admin123".equals(password)) {
	            out.println("<h1>Login bem-sucedido!</h1>");
	        } else {
	            out.println("<h1>Usu�rio ou senha inv�lidos.</h1>");
	        }
		
	}

}
